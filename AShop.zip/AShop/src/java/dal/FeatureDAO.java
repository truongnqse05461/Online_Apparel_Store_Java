/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.FeatureModel;

/**
 *
 * @author truon
 */
public class FeatureDAO extends BaseDAO<FeatureModel>{

    @Override
    public ArrayList<FeatureModel> all() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public FeatureModel get(String id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void insert(FeatureModel model) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    public FeatureModel get(int id){
        try {
            String sql = "SELECT [featureid]\n" +
                        "      ,[url]\n" +
                        "  FROM [Features]\n" +
                        "  WHERE [featureid] = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            FeatureModel feature = new FeatureModel();
            while(rs.next()){
                feature.setFeatureid(rs.getInt("featureid"));
                feature.setUrl(rs.getString("url"));
            }
            ps.close();
            return feature;
        } catch (SQLException ex) {
            Logger.getLogger(FeatureDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
