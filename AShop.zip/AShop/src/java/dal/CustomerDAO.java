/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.CustomerModel;

/**
 *
 * @author truon
 */
public class CustomerDAO extends BaseDAO<CustomerModel>{

    @Override
    public ArrayList<CustomerModel> all() {
        try {
            ArrayList<CustomerModel> customers = new ArrayList<>();
            String sql = "SELECT [cus_phone]\n" +
                    "      ,[name]\n" +
                    "      ,[email]\n" +
                    "      ,[password]\n" +
                    "      ,[zip_code]\n" +
                    "      ,[address]\n" +
                    "  FROM [Customer]";
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                CustomerModel c = new CustomerModel();
                c.setId(rs.getString("cus_phone"));
                c.setName(rs.getString("name"));
                c.setEmail(rs.getString("email"));
                c.setPassword(rs.getString("password"));
                c.setZipCode(rs.getInt("zip_code"));
                c.setAddress(rs.getString("address"));
                customers.add(c);
            }
            ps.close();
            return customers;
        } catch (SQLException ex) {
            Logger.getLogger(CustomerDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public CustomerModel get(String id) {
        try {
            String sql = "SELECT [cus_phone]\n" +
                    "      ,[name]\n" +
                    "      ,[email]\n" +
                    "      ,[password]\n" +
                    "      ,[zip_code]\n" +
                    "      ,[address]\n" +
                    "  FROM [Customer]\n" +
                    "  WHERE [cus_phone] = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            CustomerModel cust = new CustomerModel();
            while(rs.next()){
                cust.setId(id);
                cust.setName(rs.getString("name"));
                cust.setEmail(rs.getString("email"));
                cust.setPassword(rs.getString("password"));
                cust.setZipCode(rs.getInt("zip_code"));
                cust.setAddress(rs.getString("address"));
            }
            return cust;
        } catch (SQLException ex) {
            Logger.getLogger(CustomerDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public void insert(CustomerModel model) {
        try {
            String sql = "INSERT Customer(cus_phone, name, email, password, zip_code, address)\n" +
                    "VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, model.getId());
            ps.setString(2, model.getName());
            ps.setString(3, model.getEmail());
            ps.setString(4, model.getPassword());
            ps.setInt(5, model.getZipCode());
            ps.setString(6, model.getAddress());
            ps.executeUpdate();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(CustomerDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
