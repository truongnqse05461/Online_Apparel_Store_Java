/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.BrandModel;
import model.CategoryModel;
import model.ProductModel;

/**
 *
 * @author truon
 */
public class ProductDAO extends BaseDAO<ProductModel>{

    @Override
    public ArrayList<ProductModel> all() {
        try {
            ArrayList<ProductModel> products = new ArrayList<>();
            String sql = "SELECT [prodID]\n" +
                    "      ,[name]\n" +
                    "      ,[price]\n" +
                    "      ,[quantity]\n" +
                    "      ,[detail]\n" +
                    "      ,[image]\n" +
                    "      ,[brandID]\n" +
                    "      ,[cateID]\n" +
                    "  FROM [Product]";
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                ProductModel prod = new ProductModel();
                prod.setId(rs.getString("prodID"));
                prod.setName(rs.getString("name"));
                prod.setPrice(rs.getFloat("price"));
                prod.setQuantity(rs.getInt("quantity"));
                prod.setDetail(rs.getString("detail"));
                prod.setImagePath(rs.getString("image"));
                BrandDAO brand_db = new BrandDAO();
                BrandModel brand = brand_db.get(rs.getString("brandID"));
                prod.setBrand(brand);
                CategoryDAO cate_db = new CategoryDAO();
                CategoryModel category = cate_db.get(rs.getString("cateID"));
                prod.setCategory(category);
                products.add(prod);
            }
            ps.close();
            return products;
        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public ProductModel get(String id) {
        try {
            String sql = "SELECT [prodID]\n" +
                    "      ,[name]\n" +
                    "      ,[price]\n" +
                    "      ,[quantity]\n" +
                    "      ,[detail]\n" +
                    "      ,[image]\n" +
                    "      ,[brandID]\n" +
                    "      ,[cateID]\n" +
                    "  FROM [Product]\n" +
                    "  WHERE [prodID] = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            ProductModel prod = new ProductModel();
            while(rs.next()){
                prod.setId(rs.getString("prodID"));
                prod.setName(rs.getString("name"));
                prod.setPrice(rs.getFloat("price"));
                prod.setQuantity(rs.getInt("quantity"));
                prod.setDetail(rs.getString("detail"));
                prod.setImagePath(rs.getString("image"));
                BrandDAO brand_db = new BrandDAO();
                BrandModel brand = brand_db.get(rs.getString("brandID"));
                prod.setBrand(brand);
                CategoryDAO cate_db = new CategoryDAO();
                CategoryModel category = cate_db.get(rs.getString("cateID"));
                prod.setCategory(category);
            }
            ps.close();
            return prod;
        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public void insert(ProductModel model) {
        try {
            String sql = "INSERT Product(prodID, name, price, quantity, image, brandID, cateID, detail)\n" +
                    "VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, model.getId());
            ps.setString(2, model.getName());
            ps.setFloat(3, model.getPrice());
            ps.setInt(4, model.getQuantity());
            ps.setString(5, model.getImagePath());
            ps.setString(6, model.getBrand().getId());
            ps.setString(7, model.getCategory().getId());
            ps.setString(8, model.getDetail());
            ps.executeUpdate();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void update(ProductModel model){
        try {
            String sql = "UPDATE Product\n" +
                    "SET name = ?,\n" +
                    "	price = ?,\n" +
                    "	quantity = ?,\n" +
                    "	image = ?,\n" +
                    "	brandID = ?,\n" +
                    "	cateID = ?,\n" +
                    "	detail = ?\n" +
                    "WHERE prodID = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, model.getName());
            ps.setFloat(2, model.getPrice());
            ps.setInt(3, model.getQuantity());
            ps.setString(4, model.getImagePath());
            ps.setString(5, model.getBrand().getId());
            ps.setString(6, model.getCategory().getId());
            ps.setString(7, model.getDetail());
            ps.setString(8, model.getId());
            ps.executeUpdate();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void updateQuantity(int quantity, String prodID){
        try {
            String sql = "UPDATE Product\n" +
                    "SET quantity = ?\n" +
                    "WHERE prodID = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, quantity);
            ps.setString(2, prodID);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void delete(String prodID){
        try {
            String sql = "DELETE FROM Product\n" +
                    "WHERE prodID = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, prodID);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public ArrayList<ProductModel> getProductsbyCate(String cateID, String keyword, String brandID) {
        try {
            ArrayList<ProductModel> products = new ArrayList<>();
            String sql = "SELECT [prodID]\n" +
                    "      ,[name]\n" +
                    "      ,[price]\n" +
                    "      ,[quantity]\n" +
                    "      ,[detail]\n" +
                    "      ,[image]\n" +
                    "      ,[brandID]\n" +
                    "      ,[cateID]\n" +
                    "  FROM [Product]\n" +
                    "  WHERE 1=1 ";
            HashMap<Integer, Object[]> params = new HashMap<>();
            int param_index = 0;
            if(!cateID.equalsIgnoreCase("all")){
                param_index ++;
                sql += " AND [cateID] = ? ";
                Object [] param = {"STRING", cateID};
                params.put(param_index, param);
            }
            if(keyword.length() != 0){
                param_index ++;
                sql += " AND name like '%' +?+ '%' ";
                Object [] param = {"STRING", keyword};
                params.put(param_index, param);
            }
            if(!brandID.equalsIgnoreCase("all")){
                param_index ++;
                sql += " AND [brandID] = ? ";
                Object [] param = {"STRING", brandID};
                params.put(param_index, param);
            }
            PreparedStatement ps = connection.prepareStatement(sql);
            for (Map.Entry<Integer, Object[]> entry : params.entrySet()) {
                Integer key = entry.getKey();
                Object[] value = entry.getValue();
                if(value[0].toString().equals("STRING")){
                    ps.setString(key, value[1].toString());
                }
            }
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                ProductModel prod = new ProductModel();
                prod.setId(rs.getString("prodID"));
                prod.setName(rs.getString("name"));
                prod.setPrice(rs.getFloat("price"));
                prod.setQuantity(rs.getInt("quantity"));
                prod.setDetail(rs.getString("detail"));
                prod.setImagePath(rs.getString("image"));
                BrandModel brand = new BrandModel();
                brand.setId(rs.getString("brandID"));
                prod.setBrand(brand);
                CategoryModel category = new CategoryModel();
                category.setId(rs.getString("cateID"));
                prod.setCategory(category);
                products.add(prod);
            }
            ps.close();
            return products;
        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
