/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.CategoryModel;

/**
 *
 * @author truon
 */
public class CategoryDAO extends BaseDAO<CategoryModel>{

    @Override
    public ArrayList<CategoryModel> all() {
        try {
            ArrayList<CategoryModel> categories = new ArrayList<>();
            String sql = "SELECT [cateID]\n" +
                    "      ,[name]\n" +
                    "      ,[image]\n" +
                    "  FROM [Categories]";
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                CategoryModel c = new CategoryModel();
                c.setId(rs.getString("cateID"));
                c.setName(rs.getString("name"));
                c.setImagePath(rs.getString("image"));
                categories.add(c);
            }
            ps.close();
            return categories;
        } catch (SQLException ex) {
            Logger.getLogger(CategoryDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public CategoryModel get(String id) {
        try {
            ArrayList<CategoryModel> categories = new ArrayList<>();
            String sql = "SELECT [cateID]\n" +
                    "      ,[name]\n" +
                    "      ,[image]\n" +
                    "  FROM [Categories]\n"
                    + "WHERE cateID = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            CategoryModel c = new CategoryModel();
            while(rs.next()){
                c.setId(rs.getString("cateID"));
                c.setName(rs.getString("name"));
                c.setImagePath(rs.getString("image"));
            }
            ps.close();
            return c;
        } catch (SQLException ex) {
            Logger.getLogger(CategoryDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public void insert(CategoryModel model) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
