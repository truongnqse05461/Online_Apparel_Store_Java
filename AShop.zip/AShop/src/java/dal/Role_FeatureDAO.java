/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.FeatureModel;
import model.RoleModel;
import model.Role_FeatureModel;
import model.Role_UserModel;

/**
 *
 * @author truon
 */
public class Role_FeatureDAO extends BaseDAO<Role_FeatureModel>{

    @Override
    public ArrayList<Role_FeatureModel> all() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Role_FeatureModel get(String id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void insert(Role_FeatureModel model) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    public ArrayList<Role_FeatureModel> getFeaturebyRole(Role_UserModel role_user){
        try {
            ArrayList<Role_FeatureModel> role_features = new ArrayList<>();
            String sql = "SELECT roleid, featureid\n" +
                    "FROM Role_Feature\n" +
                    "WHERE roleid = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, role_user.getRole().getRoleid());
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                Role_FeatureModel role_feature = new Role_FeatureModel();
                FeatureDAO f_db = new FeatureDAO();
                FeatureModel feature = f_db.get(rs.getInt("featureid"));
                RoleModel role = new RoleModel();
                role.setRoleid(rs.getInt("roleid"));
                role_feature.setRole(role);
                role_feature.setFeature(feature);
                role_features.add(role_feature);
            }
            ps.close();
            return role_features;
        } catch (SQLException ex) {
            Logger.getLogger(Role_FeatureDAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            Logger.getLogger(Role_FeatureDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
