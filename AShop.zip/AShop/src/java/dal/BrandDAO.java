/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.BrandModel;

/**
 *
 * @author truon
 */
public class BrandDAO extends BaseDAO<BrandModel>{

    @Override
    public ArrayList<BrandModel> all() {
        try {
            ArrayList<BrandModel> brands = new ArrayList<>();
            String sql = "SELECT [brandID]\n" +
                    "      ,[name]\n" +
                    "      ,[info]\n" +
                    "  FROM [Brand]";
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                BrandModel brand = new BrandModel();
                brand.setId(rs.getString("brandID"));
                brand.setInfo(rs.getString("info"));
                brand.setName(rs.getString("name"));
                brands.add(brand);
            }
            ps.close();
            return brands;
        } catch (SQLException ex) {
            Logger.getLogger(BrandDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public BrandModel get(String id) {
        try {
            ArrayList<BrandModel> brands = new ArrayList<>();
            String sql = "SELECT [brandID]\n" +
                    "      ,[name]\n" +
                    "      ,[info]\n" +
                    "  FROM [Brand]\n"
                    + "WHERE brandID = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            BrandModel brand = new BrandModel();
            while(rs.next()){
                brand.setId(rs.getString("brandID"));
                brand.setInfo(rs.getString("info"));
                brand.setName(rs.getString("name"));
            }
            ps.close();
            return brand;
        } catch (SQLException ex) {
            Logger.getLogger(BrandDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public void insert(BrandModel model) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
