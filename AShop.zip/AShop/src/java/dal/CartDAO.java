/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.BillModel;
import model.CartModel;
import model.ProductModel;

/**
 *
 * @author truon
 */
public class CartDAO extends BaseDAO<CartModel>{

    @Override
    public ArrayList<CartModel> all() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public CartModel get(String id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void insert(CartModel model) {
        try {
            String sql = "INSERT Cart(prodID,billID,quantity,status)\n" +
                    "VALUES (?,?,?,?)";
            PreparedStatement ps = connection.prepareStatement(sql);
            String cart = model.getProduct().getId();
            ps.setString(1, model.getProduct().getId());
            ps.setString(2, model.getBill().getId());
            ps.setInt(3, model.getQuantity());
            ps.setBoolean(4, model.isStatus());
            ps.executeUpdate();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(CartDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public ArrayList<CartModel> getCartsbyStatus(BillModel bill, boolean status){
        if(bill==null) return null;
        try {
            ArrayList<CartModel> carts = new ArrayList<>();
            String sql = "SELECT [prodID]\n" +
                    "      ,[billID]\n" +
                    "      ,[quantity]\n" +
                    "      ,[status]\n" +
                    "  FROM [Cart]\n" +
                    "  WHERE [billID] = ?\n" +
                    "  AND [status] = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, bill.getId());
            ps.setBoolean(2, status);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                CartModel cart = new CartModel();
                cart.setBill(bill);
                
                ProductDAO prod_DB = new ProductDAO();
                ProductModel product = prod_DB.get(rs.getString("prodID"));
                cart.setProduct(product);
                cart.setQuantity(rs.getInt("quantity"));
                cart.setStatus(status);
                carts.add(cart);
            }
            ps.close();
            return carts;
        } catch (SQLException ex) {
            Logger.getLogger(CartDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    public ArrayList<CartModel> getCartsbyBill(BillModel bill){
        if(bill==null) return null;
        try {
            ArrayList<CartModel> carts = new ArrayList<>();
            String sql = "SELECT [prodID]\n" +
                    "      ,[billID]\n" +
                    "      ,[quantity]\n" +
                    "      ,[status]\n" +
                    "  FROM [Cart]\n" +
                    "  WHERE [billID] = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, bill.getId());
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                CartModel cart = new CartModel();
                cart.setBill(bill);
                
                ProductDAO prod_DB = new ProductDAO();
                ProductModel product = prod_DB.get(rs.getString("prodID"));
                cart.setProduct(product);
                cart.setQuantity(rs.getInt("quantity"));
                cart.setStatus(rs.getBoolean("status"));
                carts.add(cart);
            }
            ps.close();
            return carts;
        } catch (SQLException ex) {
            Logger.getLogger(CartDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    public void deleteCartbyBill(String billID){
        try {
            String sql = "DELETE FROM Cart\n" +
                    "WHERE billID = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, billID);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(CartDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public CartModel getCartbyProductandBill(String prodID, String billID){
        try {
            String sql = "SELECT [quantity]\n" +
                    "      ,[status]\n" +
                    "  FROM [Cart]\n" +
                    "  WHERE prodID = ?\n" +
                    "  AND billID = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, prodID);
            ps.setString(2, billID);
            ResultSet rs = ps.executeQuery();
            CartModel cart = new CartModel();
            while(rs.next()){
                ProductDAO prod_DB = new ProductDAO();
                ProductModel product = prod_DB.get(prodID);
                BillDAO bill_DB = new BillDAO();
                BillModel bill = bill_DB.get(billID);
                cart.setProduct(product);
                cart.setBill(bill);
                cart.setQuantity(rs.getInt("quantity"));
                cart.setStatus(rs.getBoolean("status"));
            }
            ps.close();
            return cart;
        } catch (SQLException ex) {
            Logger.getLogger(CartDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    public void update(CartModel cart){
        try {
            String sql = "UPDATE Cart\n" +
                    "SET quantity = ?,\n" +
                    "	status = ?\n" +
                    "WHERE prodID = ?\n" +
                    "AND billID = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, cart.getQuantity());
            ps.setBoolean(2, cart.isStatus());
            ps.setString(3, cart.getProduct().getId());
            ps.setString(4, cart.getBill().getId());
            ps.executeUpdate();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(CartDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
