/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.CustomerModel;
import model.RoleModel;
import model.Role_UserModel;

/**
 *
 * @author truon
 */
public class Role_UserDAO extends BaseDAO<Role_UserModel>{

    @Override
    public ArrayList<Role_UserModel> all() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Role_UserModel get(String id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void insert(Role_UserModel model) {
        try {
            String sql = "INSERT Role_User(roleid,cus_phone)\n" +
                    "VALUES(?,?)";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, model.getRole().getRoleid());
            ps.setString(2, model.getUser().getId());
            ps.executeUpdate();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(Role_UserDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public ArrayList<Role_UserModel> getRolebyUsername(CustomerModel user){
        try {
            ArrayList<Role_UserModel> role_users = new ArrayList<>();
            String sql = "SELECT roleid,cus_phone\n" +
                    "FROM Role_User\n" +
                    "WHERE cus_phone = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, user.getId());
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                Role_UserModel role_user = new Role_UserModel();
                RoleModel role = new RoleModel();
                role.setRoleid(rs.getInt("roleid"));
                role_user.setRole(role);
                role_user.setUser(user);
                role_users.add(role_user);
            }
            ps.close();
            return role_users;
        } catch (SQLException ex) {
            Logger.getLogger(Role_UserDAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            Logger.getLogger(Role_UserDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
