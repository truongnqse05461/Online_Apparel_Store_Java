/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.BillModel;
import model.CustomerModel;

/**
 *
 * @author truon
 */
public class BillDAO extends BaseDAO<BillModel>{

    @Override
    public ArrayList<BillModel> all() {
        try {
            String sql = "SELECT [billID]\n" +
                    "      ,[cus_phone]\n" +
                    "      ,[date]\n" +
                    "      ,[total]\n" +
                    "      ,[status]\n" +
                    "  FROM [Bill]";
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            ArrayList<BillModel> bills = new ArrayList<>();
            while(rs.next()){
                BillModel bill = new BillModel();
                bill.setId(rs.getString("billID"));
                CustomerDAO cust_DB = new CustomerDAO();
                CustomerModel customer = cust_DB.get(rs.getString("cus_phone"));
                bill.setCustomer(customer);
                bill.setDate(rs.getDate("date"));
                bill.setTotal(rs.getFloat("total"));
                bill.setStatus(rs.getString("status"));
                bills.add(bill);
            }
            ps.close();
            return bills;
        } catch (SQLException ex) {
            Logger.getLogger(BillDAO.class.getName()).log(Level.SEVERE, null, ex);
        } 
        return null;
    }

    @Override
    public BillModel get(String id) {
        try {
            String sql = "SELECT [billID]\n" +
                    "      ,[cus_phone]\n" +
                    "      ,[date]\n" +
                    "      ,[total]\n" +
                    "      ,[status]\n" +
                    "  FROM [Bill]\n" +
                    "  WHERE billID = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            BillModel bill = new BillModel();
            while(rs.next()){
                bill.setId(rs.getString("billID"));
                CustomerDAO cust_DB = new CustomerDAO();
                CustomerModel customer = cust_DB.get(rs.getString("cus_phone"));
                bill.setCustomer(customer);
                bill.setDate(rs.getDate("date"));
                bill.setTotal(rs.getFloat("total"));
                bill.setStatus(rs.getString("status"));
            }
            ps.close();
            return bill;
        } catch (SQLException ex) {
            Logger.getLogger(BillDAO.class.getName()).log(Level.SEVERE, null, ex);
        } 
        return null;
    }

    @Override
    public void insert(BillModel model) {
        try {
            String sql = "INSERT [Bill] ([billID], [cus_phone], [date], [total], [status]) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = connection.prepareStatement(sql);
            
            ps.setString(1, model.getId());
            String id = model.getId();
            ps.setString(2, model.getCustomer().getId());
            ps.setDate(3, model.getDate());
            float t = model.getTotal();
            ps.setFloat(4, model.getTotal());
            ps.setString(5, model.getStatus());
            ps.executeUpdate();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(BillDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public BillModel getCustBillbyStatus(CustomerModel customer, String status){
        try {
            String sql = "SELECT [billID]\n" +
                    "      ,[cus_phone]\n" +
                    "      ,[date]\n" +
                    "      ,[total]\n" +
                    "      ,[status]\n" +
                    "  FROM [Bill]\n" +
                    "  WHERE [cus_phone] = ?\n" +
                    "  AND [status] = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            String phone = customer.getId();
            ps.setString(1, customer.getId());
            ps.setString(2, status);
            ResultSet rs = ps.executeQuery();
            BillModel bill = new BillModel();
            while(rs.next()){
                bill.setId(rs.getString("billID"));
                bill.setCustomer(customer);
                bill.setDate(rs.getDate("date"));
                bill.setTotal(rs.getFloat("total"));
                bill.setStatus(rs.getString("status"));
            }
            ps.close();
            return bill;
        } catch (SQLException ex) {
            Logger.getLogger(BillDAO.class.getName()).log(Level.SEVERE, null, ex);
        } 
        return null;
    }
    public void updateTotal(float total, String billID){
        try {
            String sql = "UPDATE Bill\n" +
                    "SET total = ?\n" +
                    "WHERE billID = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setFloat(1, total);
            ps.setString(2, billID);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(BillDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void updateStatus(String status, String billID){
        try {
            String sql = "UPDATE Bill\n" +
                    "SET status = ?\n" +
                    "WHERE billID = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, status);
            ps.setString(2, billID);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(BillDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void delete(String billID){
        try {
            String sql = "DELETE FROM Bill\n" +
                    "WHERE billID = ? ";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, billID);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(BillDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
