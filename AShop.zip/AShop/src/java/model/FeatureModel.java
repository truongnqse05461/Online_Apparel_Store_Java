/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author truon
 */
public class FeatureModel extends BaseModel{
    private int featureid;
    private String url;

    public int getFeatureid() {
        return featureid;
    }

    public void setFeatureid(int featureid) {
        this.featureid = featureid;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
    
}
