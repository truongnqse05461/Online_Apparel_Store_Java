/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.auth;

import controller.BaseController;
import dal.CustomerDAO;
import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.CustomerModel;

/**
 *
 * @author truon
 */
public class AuthenticationController extends BaseController{

    @Override
    protected void processPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String id_phone = req.getParameter("phone");
        String password = req.getParameter("password");
        String url = req.getParameter("url");
        boolean isCorrectUser = false;
        CustomerDAO cust_DB = new CustomerDAO();
        ArrayList<CustomerModel> customers = cust_DB.all();
        for (CustomerModel customer : customers) {
            if(customer.getId().equals(id_phone) && customer.getPassword().equals(password)){
                isCorrectUser = true;
                req.getSession().setAttribute("user", customer);
                break;
            }
        }
        if(isCorrectUser){
            if(req.getParameter("isRemember") != null ){
                Cookie cookie = new Cookie("c_user", id_phone);
                cookie.setMaxAge(60*60*24*2);
                resp.addCookie(cookie);
            }
            resp.sendRedirect(url);
        }else{
            req.setAttribute("error", "user or password that you entered is incorrect");
            req.getRequestDispatcher("authentication/login.jsp").forward(req, resp);
        }
        
    }

    @Override
    protected void processGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if(isAuthenticated(req) || isHadCookie(req)){
            resp.sendRedirect("homepage");
        }else{
            String url = (req.getParameter("url") != null) ? req.getParameter("url") : "homepage";
            req.setAttribute("url", url);
            req.getRequestDispatcher("authentication/login.jsp").forward(req, resp);
        }
    }
    private boolean isAuthenticated(HttpServletRequest req){
        CustomerModel custAccount = (CustomerModel)req.getSession().getAttribute("user");
        return custAccount!= null;
    }
    private boolean isHadCookie(HttpServletRequest req){
        Cookie[] cookies = req.getCookies();
        if(cookies !=null)
        {
            for (Cookie cooky : cookies) {
                if(cooky.getName().equals("c_user"))
                {
                   return true;
                  
                }
            }
            return false;
        }
        return false;
    }
}
