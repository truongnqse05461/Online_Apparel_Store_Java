/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.auth;

import controller.BaseController;
import dal.CustomerDAO;
import dal.Role_UserDAO;
import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.CustomerModel;
import model.RoleModel;
import model.Role_UserModel;

/**
 *
 * @author truon
 */
public class SignUpController extends BaseController{

    @Override
    protected void processPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String phone = req.getParameter("phone");
        String first_name = req.getParameter("first_name");
        String last_name = req.getParameter("last_name");
        String email = req.getParameter("email");
        String address = req.getParameter("address");
        String newPassword = req.getParameter("newpassword");
        String rePassword = req.getParameter("rePassword");
        int zipCode = Integer.parseInt(req.getParameter("zipCode"));
        CustomerDAO cust_DB = new CustomerDAO();
        ArrayList<CustomerModel> customers = cust_DB.all();
        boolean isExist = false;
        for (CustomerModel customer : customers) {
            if(customer.getId().equals(phone)){
                req.setAttribute("error", "this phone number was registered!");
                isExist = true;
                break;
            }
        }
        if(isExist){
            req.getRequestDispatcher("signup.jsp").forward(req, resp);
        }else{
            if(!newPassword.equalsIgnoreCase(rePassword)){
                req.setAttribute("error", "Reconfirm password is incorrect!");
                req.getRequestDispatcher("signup.jsp").forward(req, resp);
            }else{
                CustomerModel customer = new CustomerModel();
                customer.setId(phone);
                customer.setName(first_name+" "+last_name);
                customer.setPassword(newPassword);
                customer.setEmail(email);
                customer.setAddress(address);
                customer.setZipCode(zipCode);
                cust_DB.insert(customer);
                RoleModel role = new RoleModel();
                role.setRoleid(3);
                Role_UserModel role_user = new Role_UserModel();
                role_user.setRole(role);
                role_user.setUser(customer);
                Role_UserDAO role_user_db = new Role_UserDAO();
                role_user_db.insert(role_user);
                resp.sendRedirect("login");
            }
        }
    }

    @Override
    protected void processGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("authentication/signup.jsp").forward(req, resp);
    }
    
}
