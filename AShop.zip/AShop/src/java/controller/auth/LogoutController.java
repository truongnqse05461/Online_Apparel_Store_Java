/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.auth;

import controller.BaseController;
import dal.CustomerDAO;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.CustomerModel;

/**
 *
 * @author truon
 */
public class LogoutController extends BaseController{
    
    protected void processRequest(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        CustomerModel currentAccount = getCurrentAccount(req);
        req.getSession().setMaxInactiveInterval(0);
        Cookie c = new Cookie("c_user", currentAccount.getId());
        c.setMaxAge(0);
        resp.addCookie(c);
        //String url = req.getHeader("referer");
        resp.sendRedirect("login");
    } 
    @Override
    protected void processPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req, resp);
    }

    @Override
    protected void processGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req, resp);
    }
    public CustomerModel getCurrentAccount(HttpServletRequest req){
        CustomerDAO cust_DB = new CustomerDAO();
       // ArrayList<CustomerModel> customers = cust_DB.all();
        CustomerModel currentAccount = (CustomerModel)req.getSession().getAttribute("user");
        String currentUser = null;
        if(currentAccount == null){
            Cookie[] cookies = req.getCookies();
            if(cookies !=null)
            {
                for (Cookie cooky : cookies) {
                    if(cooky.getName().equals("c_user"))
                    {
                        currentUser = cooky.getValue();
                        break;
                    }
                }
            }
            currentAccount = cust_DB.get(currentUser);
        }
        return currentAccount;
    }
    
}
