/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.bill;

import controller.AuthenticationBaseController;
import controller.BaseController;
import dal.BillDAO;
import dal.CartDAO;
import dal.CustomerDAO;
import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.BillModel;
import model.CartModel;
import model.CustomerModel;

/**
 *
 * @author truon
 */
public class DetailController extends AuthenticationBaseController{

    @Override
    protected void processPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String billID = req.getParameter("id");
        String status = req.getParameter("status");
        String checkStatus = req.getParameter("checkStatus");
        if(checkStatus != null){
            status = "completed";
        }
        BillDAO bill_db = new BillDAO();
        if(req.getParameter("btnSubmit").equalsIgnoreCase("Update")){
            bill_db.updateStatus(status, billID);
        }else{
            CartDAO cart_db = new CartDAO();
            cart_db.deleteCartbyBill(billID);
            bill_db.delete(billID);
        }
        resp.sendRedirect("list");
    }

    @Override
    protected void processGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String id = req.getParameter("id");
        if(id == null){
            resp.sendRedirect("list");
        }else{
            BillDAO bill_db = new BillDAO();
            BillModel bill = bill_db.get(id);
            CartDAO cart_db = new CartDAO();
            ArrayList<CartModel> carts = cart_db.getCartsbyBill(bill);
            req.setAttribute("carts", carts);
            req.setAttribute("bill", bill);
            CustomerModel currentAccount = getCurrentAccount(req);
            if(currentAccount.getId() != null){
                req.setAttribute("currentAccount", currentAccount);
            }
            req.getRequestDispatcher("detail.jsp").forward(req, resp);
        }
    }
    public CustomerModel getCurrentAccount(HttpServletRequest req){
        CustomerDAO cust_DB = new CustomerDAO();
       // ArrayList<CustomerModel> customers = cust_DB.all();
        CustomerModel currentAccount = (CustomerModel)req.getSession().getAttribute("user");
        String currentUser = null;
        if(currentAccount == null){
            Cookie[] cookies = req.getCookies();
            if(cookies !=null)
            {
                for (Cookie cooky : cookies) {
                    if(cooky.getName().equals("c_user"))
                    {
                        currentUser = cooky.getValue();
                        break;
                    }
                }
            }
            currentAccount = cust_DB.get(currentUser);
        }
        return currentAccount;
    }
}
