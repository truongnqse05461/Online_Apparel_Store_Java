/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.product;

import controller.AuthenticationBaseController;
import controller.BaseController;
import dal.BrandDAO;
import dal.CategoryDAO;
import dal.CustomerDAO;
import dal.ProductDAO;
import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.BrandModel;
import model.CategoryModel;
import model.CustomerModel;
import model.ProductModel;

/**
 *
 * @author truon
 */
public class DisplayProductController extends BaseController{

    protected void processRequest(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String id = req.getParameter("cate");
        id = (id == null || id == "") ? "all":id;
        String keyword = req.getParameter("search");
        keyword = (keyword == null) ? "" : keyword;
        String brandID = req.getParameter("brand");
        brandID = (brandID == null || brandID == "") ? "all":brandID;
        req.setAttribute("brandID", brandID);
        req.setAttribute("keyword", keyword);
        req.setAttribute("cateId", id);
        ProductDAO prod_db = new ProductDAO();
        ArrayList<ProductModel> products = prod_db.getProductsbyCate(id, keyword, brandID);
        req.setAttribute("products", products);
        CategoryDAO cate_db = new CategoryDAO();
        ArrayList<CategoryModel> categories = cate_db.all();
        req.setAttribute("categories", categories);
        BrandDAO brand_db = new BrandDAO();
        ArrayList<BrandModel> brands = brand_db.all();
        req.setAttribute("brands", brands);
        CustomerModel currentAccount = getCurrentAccount(req);
        if(currentAccount.getId() != null){
            req.setAttribute("currentAccount", currentAccount);
        }
        req.getRequestDispatcher("shop.jsp").forward(req, resp);
        
    }
    @Override
    protected void processPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req, resp);
    }

    @Override
    protected void processGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req, resp);
    }
    public CustomerModel getCurrentAccount(HttpServletRequest req){
        CustomerDAO cust_DB = new CustomerDAO();
       // ArrayList<CustomerModel> customers = cust_DB.all();
        CustomerModel currentAccount = (CustomerModel)req.getSession().getAttribute("user");
        String currentUser = null;
        if(currentAccount == null){
            Cookie[] cookies = req.getCookies();
            if(cookies !=null)
            {
                for (Cookie cooky : cookies) {
                    if(cooky.getName().equals("c_user"))
                    {
                        currentUser = cooky.getValue();
                        break;
                    }
                }
            }
            currentAccount = cust_DB.get(currentUser);
        }
        return currentAccount;
    }
}
