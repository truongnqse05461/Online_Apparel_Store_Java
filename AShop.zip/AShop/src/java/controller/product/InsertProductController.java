/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.product;

import controller.AuthenticationBaseController;
import controller.BaseController;
import dal.BrandDAO;
import dal.CategoryDAO;
import dal.CustomerDAO;
import dal.ProductDAO;
import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.BrandModel;
import model.CategoryModel;
import model.CustomerModel;
import model.ProductModel;

/**
 *
 * @author truon
 */
public class InsertProductController extends AuthenticationBaseController{

    @Override
    protected void processPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String id = req.getParameter("id");
        String name = req.getParameter("name");
        float price = Float.parseFloat(req.getParameter("price"));
        int quantity = Integer.parseInt(req.getParameter("quantity"));
        String imagePath = req.getParameter("imagePath");
        String brandID = req.getParameter("brand");
        String cateID = req.getParameter("category");
        String detail = req.getParameter("detail");
        ProductModel product = new ProductModel();
        product.setId(id);
        product.setName(name);
        product.setPrice(price);
        product.setQuantity(quantity);
        product.setImagePath(imagePath);
        BrandModel brand = new BrandModel();
        brand.setId(brandID);
        product.setBrand(brand);
        CategoryModel category = new CategoryModel();
        category.setId(cateID);
        product.setCategory(category);
        product.setDetail(detail);
        ProductDAO prod_db = new ProductDAO();
        prod_db.insert(product);
        resp.sendRedirect("list");
    }

    @Override
    protected void processGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        BrandDAO brand_db = new BrandDAO();
        ArrayList<BrandModel> brands = brand_db.all();
        CategoryDAO cate_db = new CategoryDAO();
        ArrayList<CategoryModel> categories = cate_db.all();
        req.setAttribute("brands", brands);
        req.setAttribute("categories", categories);
        CustomerModel currentAccount = getCurrentAccount(req);
        if(currentAccount.getId() != null){
            req.setAttribute("currentAccount", currentAccount);
        }
        req.getRequestDispatcher("insert.jsp").forward(req, resp);
    }
    public CustomerModel getCurrentAccount(HttpServletRequest req){
        CustomerDAO cust_DB = new CustomerDAO();
       // ArrayList<CustomerModel> customers = cust_DB.all();
        CustomerModel currentAccount = (CustomerModel)req.getSession().getAttribute("user");
        String currentUser = null;
        if(currentAccount == null){
            Cookie[] cookies = req.getCookies();
            if(cookies !=null)
            {
                for (Cookie cooky : cookies) {
                    if(cooky.getName().equals("c_user"))
                    {
                        currentUser = cooky.getValue();
                        break;
                    }
                }
            }
            currentAccount = cust_DB.get(currentUser);
        }
        return currentAccount;
    }
}
