/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dal.CustomerDAO;
import dal.Role_FeatureDAO;
import dal.Role_UserDAO;
import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.CustomerModel;
import model.Role_FeatureModel;
import model.Role_UserModel;

/**
 *
 * @author truon
 */
public abstract class AuthenticationBaseController extends BaseController{

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if(!isHadCookie(req) && !isAuthenticated(req)){
            StringBuffer url = req.getRequestURL();
            url.append(req.getQueryString() != null ? "?"+req.getQueryString() : "");
            resp.sendRedirect("login?url="+url);
        }else{
            StringBuffer url = req.getRequestURL();
            url.append(req.getQueryString() != null ? "?"+req.getQueryString() : "");
            if(!isAuthorized(req)){
                resp.getWriter().println("Permission denied!");
            }else
                super.doGet(req, resp); //To change body of generated methods, choose Tools | Templates.
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if(!isHadCookie(req) && !isAuthenticated(req)){
            StringBuffer url = req.getRequestURL();
            url.append(req.getQueryString() != null ? "?"+req.getQueryString() : "");
            resp.sendRedirect("login?url="+url);
        }else{
            StringBuffer url = req.getRequestURL();
            url.append(req.getQueryString() != null ? "?"+req.getQueryString() : "");
            if(!isAuthorized(req)){
                resp.getWriter().println("Permission denied!");
            }else
                super.doPost(req, resp); //To change body of generated methods, choose Tools | Templates.
        }
    }
    private boolean isAuthenticated(HttpServletRequest req){
        CustomerModel custAccount = (CustomerModel)req.getSession().getAttribute("user");
        return custAccount!= null;
    }
    private boolean isHadCookie(HttpServletRequest req){
        Cookie[] cookies = req.getCookies();
        if(cookies !=null)
        {
            for (Cookie cooky : cookies) {
                if(cooky.getName().equals("c_user"))
                {
                   return true;
                  
                }
            }
            return false;
        }
        return false;
    }
    private boolean isAuthorized(HttpServletRequest req){
        StringBuffer url = req.getRequestURL();
        CustomerModel user = getCurrentAccount(req);
        String username = user.getId();
        Role_UserDAO role_user_db = new Role_UserDAO();
        ArrayList<Role_UserModel> role_users = role_user_db.getRolebyUsername(user);
        Role_FeatureDAO role_feature_db = new Role_FeatureDAO();
        for (Role_UserModel role_user : role_users) {
            ArrayList<Role_FeatureModel> role_features = role_feature_db.getFeaturebyRole(role_user);
            for (Role_FeatureModel role_feature : role_features) {
                if(url.toString().endsWith(role_feature.getFeature().getUrl())){
                    return true;
                }
            }
        }
        return false;
    }
    public CustomerModel getCurrentAccount(HttpServletRequest req){
        CustomerDAO cust_DB = new CustomerDAO();
       // ArrayList<CustomerModel> customers = cust_DB.all();
        CustomerModel currentAccount = (CustomerModel)req.getSession().getAttribute("user");
        String currentUser = null;
        if(currentAccount == null){
            Cookie[] cookies = req.getCookies();
            if(cookies !=null)
            {
                for (Cookie cooky : cookies) {
                    if(cooky.getName().equals("c_user"))
                    {
                        currentUser = cooky.getValue();
                        break;
                    }
                }
            }
            currentAccount = cust_DB.get(currentUser);
        }
        return currentAccount;
    }
}
