/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.cart;

import controller.AuthenticationBaseController;
import dal.BillDAO;
import dal.CartDAO;
import dal.CustomerDAO;
import dal.ProductDAO;
import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.BillModel;
import model.CartModel;
import model.CustomerModel;

/**
 *
 * @author truon
 */
public class CheckOutController extends AuthenticationBaseController{

    @Override
    protected void processPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        CustomerDAO cust_DB = new CustomerDAO();
       // ArrayList<CustomerModel> customers = cust_DB.all();
        CustomerModel currentAccount = (CustomerModel)req.getSession().getAttribute("user");
        String currentUser = null;
        if(currentAccount == null){
            Cookie[] cookies = req.getCookies();
            if(cookies !=null)
            {
                for (Cookie cooky : cookies) {
                    if(cooky.getName().equals("c_user"))
                    {
                        currentUser = cooky.getValue();
                        break;
                    }
                }
            }
            currentAccount = cust_DB.get(currentUser);
        }
        String phone = currentAccount.getId();
        BillDAO bill_DB = new BillDAO();
        BillModel isProcessingBill = bill_DB.getCustBillbyStatus(currentAccount, "waiting");
        CartDAO cart_DB = new CartDAO();
        ArrayList<CartModel> carts = cart_DB.getCartsbyStatus(isProcessingBill, false);
        ProductDAO prod_db = new ProductDAO();
        if(carts != null && carts.size() != 0){
            bill_DB.updateStatus("processing", isProcessingBill.getId());
            for (CartModel cart : carts) {
                prod_db.updateQuantity(cart.getProduct().getQuantity() - cart.getQuantity(), cart.getProduct().getId());
                cart.setStatus(true);
                cart_DB.update(cart);
            }
        }
        resp.sendRedirect("homepage");
    }

    @Override
    protected void processGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        CustomerModel currentAccount = getCurrentAccount(req);
        if(currentAccount.getId() != null){
            req.setAttribute("currentAccount", currentAccount);
        }
        String phone = currentAccount.getId();
        BillDAO bill_DB = new BillDAO();
        BillModel isProcessingBill = bill_DB.getCustBillbyStatus(currentAccount, "waiting");
        req.setAttribute("currentAccount", currentAccount);
        req.setAttribute("bill", isProcessingBill);
        req.getRequestDispatcher("cart/checkout.jsp").forward(req, resp);
    }
    public CustomerModel getCurrentAccount(HttpServletRequest req){
        CustomerDAO cust_DB = new CustomerDAO();
       // ArrayList<CustomerModel> customers = cust_DB.all();
        CustomerModel currentAccount = (CustomerModel)req.getSession().getAttribute("user");
        String currentUser = null;
        if(currentAccount == null){
            Cookie[] cookies = req.getCookies();
            if(cookies !=null)
            {
                for (Cookie cooky : cookies) {
                    if(cooky.getName().equals("c_user"))
                    {
                        currentUser = cooky.getValue();
                        break;
                    }
                }
            }
            currentAccount = cust_DB.get(currentUser);
        }
        return currentAccount;
    }
}
