/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.cart;

import controller.AuthenticationBaseController;
import controller.BaseController;
import dal.BillDAO;
import dal.CartDAO;
import dal.CustomerDAO;
import dal.ProductDAO;
import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.BillModel;
import model.CartModel;
import model.CustomerModel;
import model.ProductModel;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 *
 * @author truon
 */
public class InsertController extends AuthenticationBaseController{

    @Override
    protected void processPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String prodID = req.getParameter("prodID");
        String billID = req.getParameter("billID");
        String action = req.getParameter("act");
        CartDAO cart_DB = new CartDAO();
        CartModel cart = cart_DB.getCartbyProductandBill(prodID, billID);
        String quantityDiv = null;
        String afterDel = null;
        boolean isDel = false;
        BillDAO bill_DB = new BillDAO();
        if(action.equalsIgnoreCase("plus")){
            if(cart.getQuantity()+1 <= cart.getProduct().getQuantity()){
                cart.setQuantity(cart.getQuantity()+1);
                cart.getBill().setTotal(cart.getBill().getTotal() + cart.getProduct().getPrice());
                cart_DB.update(cart);
                bill_DB.updateTotal(cart.getBill().getTotal(), cart.getBill().getId());
            }
        }else if(action.equalsIgnoreCase("minus")){
            if(cart.getQuantity()-1 > 0){
                cart.setQuantity(cart.getQuantity()-1);
                cart.getBill().setTotal(cart.getBill().getTotal() - cart.getProduct().getPrice());
                cart_DB.update(cart);
                bill_DB.updateTotal(cart.getBill().getTotal(), cart.getBill().getId());
            }
        }else if(action.equalsIgnoreCase("delete")){
            //isDel = true;
            resp.getWriter().print("");
        }
        quantityDiv = "<input type=\"number\" class=\"qty-text\" id=\"${cart.product.id}\" name=\"quantity\" value=\""+cart.getQuantity()+"\" readonly >";
        //resp.getWriter().print(quantityDiv);
        
        String totalDiv = "<li><span>subtotal:</span> <span>"+cart.getBill().getTotal()+"$</span></li>\n" +
"                                <li><span>delivery:</span> <span>Free</span></li>\n" +
"                                <li><span>total:</span> <span>"+cart.getBill().getTotal()+"$</span></li>";
        JSONObject rv = new JSONObject();
        rv.put("quantityDiv", quantityDiv);
        rv.put("totalDiv", totalDiv);
        //rv.put("afterDel", afterDel);
        String gobject = rv.toJSONString();
        resp.getWriter().println(gobject);
        req.getServletContext().log(gobject);
        
        
    }

    @Override
    protected void processGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        CustomerModel currentAccount = getCurrentAccount(req);
        CustomerDAO cust_DB = new CustomerDAO();
        if(currentAccount.getId() != null){
            req.setAttribute("currentAccount", currentAccount);
        }
        BillDAO bill_DB = new BillDAO();
        BillModel isProcessingBill = bill_DB.getCustBillbyStatus(currentAccount, "waiting");
        CartDAO cart_DB = new CartDAO();
        ArrayList<CartModel> carts = cart_DB.getCartsbyStatus(isProcessingBill, false);
        String prod_Id = req.getParameter("id");
        int quantity = Integer.parseInt((req.getParameter("quantity") != null) ? req.getParameter("quantity") : "-1");
        if(prod_Id != null){
            ProductDAO prod_db = new ProductDAO();
            ProductModel product = prod_db.get(prod_Id);
            CartModel cart = new CartModel();
            cart.setProduct(product);
            cart.setQuantity((quantity != -1) ? quantity : 1);
            
            boolean isExist = false;
            if(carts != null && carts.size() != 0){
                for (CartModel c : carts) {
                    if(c.getProduct().getId().equals(cart.getProduct().getId())){
                        if(c.getQuantity()+cart.getQuantity() <= c.getProduct().getQuantity()){
                            c.setQuantity(c.getQuantity()+cart.getQuantity());
                            cart_DB.update(c);
                            c.getBill().setTotal(c.getBill().getTotal() + c.getProduct().getPrice() * cart.getQuantity());
                            bill_DB.updateTotal(c.getBill().getTotal(), c.getBill().getId());
                        }else{
                            c.setQuantity(c.getProduct().getQuantity());
                            cart_DB.update(c);
                            c.getBill().setTotal(c.getBill().getTotal() + c.getProduct().getPrice() * cart.getQuantity());
                            bill_DB.updateTotal(c.getBill().getTotal(), c.getBill().getId());
                        }
                        isExist = true;
                        break;
                    }
                }
                if(!isExist){
                    if(cart.getQuantity() <= cart.getProduct().getQuantity()){
                        carts.add(cart);
                        cart.setStatus(false);
                        cart.setBill(carts.get(0).getBill());
                        CartDAO cart_DB1 = new CartDAO();
                        cart_DB1.insert(cart);
                        cart.getBill().setTotal(cart.getBill().getTotal() + cart.getProduct().getPrice() * cart.getQuantity());
                        bill_DB.updateTotal(cart.getBill().getTotal(), cart.getBill().getId());
                    }else{
                        cart.setQuantity(cart.getProduct().getQuantity());
                        carts.add(cart);
                        cart.setStatus(false);
                        cart.setBill(carts.get(0).getBill());
                        CartDAO cart_DB1 = new CartDAO();
                        cart_DB1.insert(cart);
                        cart.getBill().setTotal(cart.getBill().getTotal() + cart.getProduct().getPrice() * cart.getQuantity());
                        bill_DB.updateTotal(cart.getBill().getTotal(), cart.getBill().getId());
                    }
                    
                }
            }else{
                carts = new ArrayList<>();
                carts.add(cart);
                BillModel newBill = new BillModel();
                newBill.setCustomer(currentAccount);
                newBill.setId("bill"+new Random().nextInt(Integer.MAX_VALUE));
                Calendar cal = Calendar.getInstance();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                String date = sdf.format(cal.getTime());
                newBill.setDate(Date.valueOf(date));
                newBill.setTotal(cart.getProduct().getPrice() * cart.getQuantity());
                newBill.setStatus("waiting");
                BillDAO bill_DB1 = new BillDAO();
                bill_DB1.insert(newBill);

                cart.setBill(newBill);
                cart.setStatus(false);
                CartDAO cart_DB2 = new CartDAO();
                cart_DB2.insert(cart);
            }
        }
        req.setAttribute("carts", carts);
        req.getRequestDispatcher("cart/cart.jsp").forward(req, resp);
    }
    public CustomerModel getCurrentAccount(HttpServletRequest req){
        CustomerDAO cust_DB = new CustomerDAO();
       // ArrayList<CustomerModel> customers = cust_DB.all();
        CustomerModel currentAccount = (CustomerModel)req.getSession().getAttribute("user");
        String currentUser = null;
        if(currentAccount == null){
            Cookie[] cookies = req.getCookies();
            if(cookies !=null)
            {
                for (Cookie cooky : cookies) {
                    if(cooky.getName().equals("c_user"))
                    {
                        currentUser = cooky.getValue();
                        break;
                    }
                }
            }
            currentAccount = cust_DB.get(currentUser);
        }
        return currentAccount;
    }
}
